package com.yourname.inventorysorter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.util.Identifier;

public class InventorySorterMod implements ModInitializer {
    public static final String MOD_ID = "inventorysorter";
    public static final Identifier SORT_PACKET_ID = new Identifier(MOD_ID, "sort");

    @Override
    public void onInitialize() {
        // 注册服务端包处理器
        ServerPlayNetworking.registerGlobalReceiver(SORT_PACKET_ID, 
            (server, player, handler, buf, sender) -> server.execute(() -> {
                sortInventory(player);
            })
        );
    }

    // 整理背包逻辑
    private static void sortInventory(PlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        List<ItemStack> items = new ArrayList<>();

        // 收集所有非空物品（0-35格：快捷栏+主背包）
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty()) items.add(stack);
        }

        // 按创造模式顺序排序
        items.sort((stack1, stack2) -> {
            int id1 = Registry.ITEM.getRawId(stack1.getItem());
            int id2 = Registry.ITEM.getRawId(stack2.getItem());
            return Integer.compare(id1, id2);
        });

        // 清空背包
        for (int i = 0; i < 36; i++) inv.setStack(i, ItemStack.EMPTY);

        // 重新放入排序后的物品
        for (int i = 0; i < items.size(); i++) {
            inv.setStack(i, items.get(i));
        }
    }
}